import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'starRating'
})
export class StarRatingPipe implements PipeTransform {

  transform(value:String): String {
    console.log(' --->',value)
    if(value >= '85'){
      return "****";
    }
    if(value < '85' && value > '60')
    {
      return "***";
    }
    return "**";
  }

}
