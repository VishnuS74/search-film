import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-filmsearch',
  templateUrl: './filmsearch.component.html',
  styleUrls: ['./filmsearch.component.css']
})
export class FilmsearchComponent implements OnInit {

  constructor() { }


  @Input() films:any;
  @Input() loggedIn:any;
  FormSubmit = false;
  filter ='';

  ngOnInit(): void {
  }

  searchFilms(event: any){

    this.filter=event.target.search.value;
    console.log('in search component ',event.target.search.value);

    this.FormSubmit=true;
    console.log('in search component FormSubmit',this.FormSubmit);
  }
}
