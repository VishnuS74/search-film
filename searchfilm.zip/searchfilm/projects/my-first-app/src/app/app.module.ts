import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChildComponent } from './child/child.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { StarRatingPipe } from './star-rating.pipe';
import { FilmComponent } from './film/film.component';
import { FilmsearchComponent } from './filmsearch/filmsearch.component';
import { NotFoundComponent } from './not-found/not-found.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginFormComponent,
    ChildComponent,
    StarRatingPipe,
    FilmComponent,
    FilmsearchComponent,
    NotFoundComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
