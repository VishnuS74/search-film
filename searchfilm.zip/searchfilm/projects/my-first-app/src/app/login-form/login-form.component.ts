import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StarRatingPipe } from '../star-rating.pipe';
import  {NgForm} from '@angular/forms';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css'],
  providers: [ StarRatingPipe  ]
})
export class LoginFormComponent implements OnInit {
  loggedIn:Boolean = false;
  constructor(private router: Router) { }


  //starRating = this.rating.transform();

  ngOnInit(): void {
  }
  
  navigatePostLogin(): void {
    this.router.navigateByUrl('/search')
    // this.router.createUrlTree(['/login'], { queryParams: { returnUrl: state.url }})
  }

  onSubmitForm(form:NgForm){
   // console.log(' before ',this.loggedIn);
    this.loggedIn=true;
    //console.log(' after ',this.loggedIn);
    this.navigatePostLogin();
  }
}