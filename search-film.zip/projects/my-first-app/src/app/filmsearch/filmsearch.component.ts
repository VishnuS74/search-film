import { Component, Input, OnInit } from '@angular/core';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-filmsearch',
  templateUrl: './filmsearch.component.html',
  styleUrls: ['./filmsearch.component.css']
})
export class FilmsearchComponent implements OnInit {

  constructor(private authenication:AuthenticationService) { }


  loggedIn = this.authenication.loggedIn;
  FormSubmit = false;
  filter ='';

  ngOnInit(): void {
  }

  searchFilms(event: any){

    this.filter=event.target.search.value;
    console.log('in search component ',event.target.search.value);

    this.FormSubmit=true;
    console.log('in search component loggedIn',this.loggedIn);
  }

  logout(){
    this.authenication.logoutUser();
  }
}
