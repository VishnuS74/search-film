import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FilmsearchComponent } from './filmsearch.component';

describe('FilmsearchComponent', () => {
  let component: FilmsearchComponent;
  let fixture: ComponentFixture<FilmsearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FilmsearchComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FilmsearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
