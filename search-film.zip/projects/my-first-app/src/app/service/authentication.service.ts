import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injectable, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { LoginRequest } from '../models/authentication/login-request';
import { RegistrationRequest } from '../models/authentication/registration-request';
import { UserResponse } from '../models/authentication/user-response';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  //loggedIn:Boolean = false;

  

  token: string | null = null

  get loggedIn(): boolean {
    return this.token != null
  }

  logoutUser(){
   // this.loggedIn=false;
    this.router.navigateByUrl('/login');
  }
  private baseUrl = 'api/user'

constructor(private httpClient: HttpClient
   , private router:Router) {}

login(loginRequest: LoginRequest): Observable<UserResponse> {
  console.log('coming inside the login',loginRequest.email);
  console.log('coming inside the login psw',loginRequest.password);
  return this.httpClient.post<UserResponse>(this.baseUrl + '/login', loginRequest)
}

register(loginRequest: LoginRequest): Observable<UserResponse> {
  const registrationRequest = new RegistrationRequest(
    loginRequest.email,
    loginRequest.password,
    'John',
    'Smith'
  )
  return this.httpClient.post<UserResponse>(this.baseUrl + '/register', registrationRequest);
}

}
