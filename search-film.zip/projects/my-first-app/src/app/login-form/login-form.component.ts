import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { StarRatingPipe } from '../star-rating.pipe';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { AuthenticationService } from '../service/authentication.service';
import { LoginRequest } from '../models/authentication/login-request';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css'],
  providers: [ StarRatingPipe  ]
})
export class LoginFormComponent implements OnInit {
  loggedIn: boolean = false;
 
  constructor(private router: Router,private authentication:AuthenticationService , private formBuilder: FormBuilder ) { }

  profileForm = new FormGroup({
    email: new FormControl(''),
    password: new FormControl(''),
  });

//  @Output() loggedIn = new EventEmitter<boolean>();
email:any;
password:any;
  //addNewTask(value: boolean) {
   // this.loggedIn.emit(value);
  //}
  //starRating = this.rating.transform();

  ngOnInit(): void {
    this.profileForm=this.formBuilder.group(
      {
  
        email: ['', [Validators.required, Validators.email]],
            password: [
              '',
              [
                Validators.required,
                Validators.minLength(6),
                Validators.maxLength(40)
              ]
            ],
      });
  }
  
  navigatePostLogin(): void {
    this.router.navigateByUrl('/search')
    // this.router.createUrlTree(['/login'], { queryParams: { returnUrl: state.url }})
  }

  onSubmitForm(){
    if (this.profileForm.invalid) {
      return;
    }
    
    //this.loggedIn = this.authenication.logUser();
    this.loggedIn = true;
    console.log('form -->',this.profileForm.value.email);
    console.log('form 2 -->',this.profileForm.value.password);
    this.email = this.profileForm.value.email;
    this.password =this.profileForm.value.password ;
   // this.login();
    //this.navigatePostLogin();
  }


  login(): void {
    this.authentication.login(this.loginRequest)
      .subscribe(response => {
        this.authentication.token = response.token;
        console.log('token -->',response.token);
       // const returnUrl = this.router.paramMap.get('returnUrl')
       // this.router.navigateByUrl(returnUrl ? `/${returnUrl}` : '')
       this.router.navigateByUrl('/search');
      },
      error =>{
        console.log(' error  token -->');
        this.router.navigateByUrl('/login');
      })
  }
  
  register(): void {
    this.authentication.register(this.loginRequest)
      .subscribe(response => {})
  }
  
  get loginRequest(): LoginRequest {
    return new LoginRequest(this.email, this.password)
  }
}